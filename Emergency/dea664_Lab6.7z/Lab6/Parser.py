import math


packet = ("4500005e000040004011df23ac1001feac12014d")

#parsing of the ip packet.

HEADER_CHECKSUM= packet[20:23]  + packet[23]

adder = 0
end = 4
i = 0

length = math.floor(len(packet) / 4)
start = 0

while i < length:
    adder = adder + int(packet[start:end], 16)
    start = end
    end = end + 4
    i += 1


total = adder    
adder = adder - int(HEADER_CHECKSUM, 16)
adder = adder + int (hex(adder)[2])
adder2 = int (hex(adder)[3:], 16)
 
mask = (1 << len(hex(adder2)[2:])*4) -1

check = hex(adder2 ^ mask)

print("Not corrupted:"  + str(check[2:] == HEADER_CHECKSUM))
print("verifying checksum")
total = total + int (hex(total)[2])
total = int (hex(total)[3:], 16)

mask = (1 << len(hex(total)[2:])*4) -1
check = hex(total ^ mask)
print(("Taking the ones’ complement yields ") + check[2:])
     

