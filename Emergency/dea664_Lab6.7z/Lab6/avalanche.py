import hashlib

string_1 = "101010101"
string_2 = "001010101"

print (("strings used are: ") + string_1 +" and " + string_2 + ("\n"))

def distance(string1, string2):

    distance = "" 
    if (len(string_1) == len(string_2)):

        for bit1, bit2 in zip(string_1, string_2):

            if(bit1 == bit2):
                distance += "1"
            else:
                distance += "0"
                
    return distance

print(("hamming distance between unhased strings: ")
      +(distance(string_1, string_2))+ ("\n"))
                
hash_md5 = hashlib.md5(distance(string_1, string_2))
print(("MD5 hamming distance: ")+
      bin(int(hash_md5.hexdigest(), 16))[2:] + ("\n"))

hash_sha1 = hashlib.sha1(distance(string_1, string_2))
print(("SHA1 hamming distance: ")+
      bin(int(hash_sha1.hexdigest(), 16))[2:]+ ("\n"))

hash_sha256 = hashlib.sha256(distance(string_1, string_2))
print(("SHA256 hamming distance: ")+
      bin(int(hash_sha256.hexdigest(), 16))[2:]+ ("\n"))
