import math


packet = ("4500005e00004000401" 
          +"1df23ac1001feac10014d0035e789004"
          +"ae5d7666f818000010002000000000564616973790675"
            +"62756e747503636f6d0000010001c00c0001000100000"
          +"09e00045bbd5f36c00c000100010000009e00045bbd5f37")

#parsing of the ip packet.

HEADER_CHECKSUM= packet[36:39]  + packet[39]

print(HEADER_CHECKSUM)

adder = 0
end = 4
i = 0

length = math.floor(len(packet) / 4)
start = 0


while i < length:
    adder = adder + int(packet[start:end], 16)
    start = end
    end = end + 4
    
    if(len(hex(adder)[2:]) > 4):

        temp = int(hex(adder)[2], 16)
        adder = int (hex(adder)[3:], 16)
        adder = adder + temp
        
    i += 1
    print (hex(adder))

print("done")
  
length = (len(hex(adder))-2)

mask = (1 << length*4) -1

check = hex(adder ^ mask)

print("Not corrupted:"  + str(check[2:] == HEADER_CHECKSUM))
print(("Taking the ones’ complement yields ") + check[2:])
     

#######################PART2##################################

#parsing of the tcp packet.

# PSUEDO HEADER
SRC_IP= packet[0:8]
DST_IP = packet[8:16]
ZEROS = packet[16:18]
PROTOCOL = packet[18:20]
PSEUDO_TL = packet[20:24]


#store packet in dictionary
IP= {'SRC_IP' : SRC_IP,
     'DST_IP' : DST_IP,
     'ZEROS' : ZEROS,
     'PROTOCOL' : PROTOCOL,
     'PSEUDO_TL' : PSEUDO_TL,
     }

print(IP)





#write to html file
f = open('udp.html','w')

message = ""


message += "<html>"
message  += "<body bgcolor=\"white\">"



message  += "<table border= \"1\" >"
message  += "<tr>"
message += '<td width="1785" align="center">%s: %s</td>' % ('SRC IP ADDR', IP['SRC_IP'])
message += "</tr>"
message  += "</table>"

message  += "<table border= \"1\" >"
message  += "<tr>"
message += '<td width="1785" align="center">%s: %s</td>' % ('DST IP ADDR', IP['DST_IP'])
message += "</tr>"
message  += "</table>"

message  += "<table border= \"1\" >"
message  += "<tr>"
message += '<td width="591" align="center">%s : %s</td>' % ('ZEROES NO', IP['ZEROS'])
message += '<td width="591" align="center">%s : %s</td>' % ('PROTOCOL', IP['PROTOCOL'])
message += '<td width="591" align="center">%s : %s</td>' % ('PSEUDO_TL', IP['PSEUDO_TL'])
message += '</tr>'
message  += "</table>"


message  += "</body>"
message  += "</html>"

f.write(message)
f.close()



        
    














