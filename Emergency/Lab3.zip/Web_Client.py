import http.client
import socket


#Client takes in server IP, port number 
server = http.client.HTTPConnection(socket.gethostname(), 12345)
server.connect()

#send request to server for object
server.request('GET', "/HelloWorld.html")

#gets response from the server
response = server.getresponse()

#make sure status of the response is good
#and print out response
if response.status == http.client.OK:
    print ("Output from HTML request")
    print(response.read().decode('utf-8'))
    print(response.status)
