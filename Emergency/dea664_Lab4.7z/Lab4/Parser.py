# This script exracts IP headers, parsers the header information into
# human readable format and saves them as pairs of <fields:value>

# It also generates an HTML file and displays the dictionary items
# in a tabular format

packet = ("450000283b" 
            "1a400080066ac40ae3010"
            "8cdc47b42c76a0050498a3c"
            "daadbd4f1f5010fd5c128a0000")

#parsing of the ip packet.
VERSION= packet[0]
HLEN = packet[1]
TOS = packet[2:3]  + packet[3]
TOTAL_LENGTH = packet[4:7] + packet[7]
IDENTIFICATION =packet[8:11] + packet[11]
SECTION= packet[12]


#Parsing of falgs and framentation offset
SECTION = int(SECTION, 16)
SECTION = '{0:04b}'.format(SECTION)
FLAGS = SECTION[0:2] + SECTION [2]



F_O = SECTION[3] + packet[13:15] +  packet[15]
TTL= packet[16:17] + packet[17]
PROTOCOL = packet[18:19] + packet[19] 
HEADER_CHECKSUM= packet[20:23]  + packet[23]
SRC_ADDR = packet[24:31] +  packet[31]
DST_ADDR = packet[32:39] + packet[39]
OPTIONS = packet[39:]


#store packet in dictionary
IP= {'VERSION' : VERSION,
     'HLEN' : HLEN,
     'TYPE OF SERVICE' : TOS,
     'TOTAL_LENGTH' : TOTAL_LENGTH,
     'IDENTIFICATION' : IDENTIFICATION,
     'FLAGS' : FLAGS,
     'FRAGMENTATION OFFSET' : F_O,
     'TIME TO LIVE' : TTL,
     'PROTOCOL' : PROTOCOL,
     'HEADER_CHECKSUM' : HEADER_CHECKSUM,
     'SRC_ADDR' : SRC_ADDR,
     'DST_ADDR' : DST_ADDR,
     'OPTIONS' : OPTIONS
     
     }

print(IP)

#write to html file
f = open('ip_packet.html','w')

message = ""

message += "<html>"
message  += "<body bgcolor=\"white\">"
message  += "<table border=\"3\" cellspacing=\"0\" cellpadding=\"20\">"

message  += "<tr>"
message += '<td>%s : %s</td>' % ('VERSION', IP['VERSION'])
message += '<td>%s : %s</td>' % ('HLEN', IP['HLEN'])
message += '<td>%s : %s</td>' % ('TYPE OF SERVICE', IP['TYPE OF SERVICE'])
message += '<td>%s : %s</td>' % ('TOTAL_LENGTH', IP['TOTAL_LENGTH'])
message += '<tr>'

message  += "<tr>"
message += '<td>%s : %s</td>' % ('IDENTIFICATION', IP['IDENTIFICATION'])
message += '<td>%s : %s</td>' % ('FLAGS', IP['FLAGS'])
message += '<td>%s : %s</td>' % ('FRAGMENTATION OFFSET', IP['FRAGMENTATION OFFSET'])
message += '<tr>'

message  += "<tr>"
message += '<td>%s : %s</td>' % ('TIME TO LIVE', IP['TIME TO LIVE'])
message += '<td>%s : %s</td>' % ('PROTOCOL', IP['PROTOCOL'])
message += '<td>%s : %s</td>' % ('HEADER_CHECKSUM', IP['HEADER_CHECKSUM'])
message += '<tr>'

message  += "<tr>"
message += '<td>%s : %s</td>' % ('SRC_ADDR', IP['SRC_ADDR'])
message += '<tr>'

message  += "<tr>"
message += '<td>%s : %s</td>' % ('DST_ADDR', IP['DST_ADDR'])
message += '<tr>'

message  += "<tr>"
message += '<td>%s : %s</td>' % ('OPTIONS', IP['OPTIONS'])
message += '<tr>'


message  += "</table>"
message  += "</body>"
message  += "</html>"

f.write(message)
f.close()




