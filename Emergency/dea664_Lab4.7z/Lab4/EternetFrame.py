# This script parses the information in each frame into human readable format
# and then shos the information in a tabular format in an html file.


frame = ("00000c9ff001d0df9ac7ccf80800450000283b1a400080066ac40ae301"
         "08cdc47b42c76a0050498a3cdaadbd398f5010fd5c281a000000000c9ff"
         "001d0df9ac7ccf80800450000283b1b400080066ac30ae30108cdc47b42c"
         "76a0050498a3cdaadbd44575010fd5c1d52000000000c9ff001d0df9ac7cc"
         "f80800450000283b1c400080066ac20ae30"
         "108cdc47b42c76a0050498a3cdaadbd4f1f5010fd5c128a0000")

#parsing of the frame.
DST_MAC_ADDR = frame[0:11] + frame[11]
SRC_MAC_ADDR = frame[12:23] + frame[23]
TYPE = frame[24:27]  + frame[27]

#splits the payload of each frame
PAYLOAD = frame.split(DST_MAC_ADDR + SRC_MAC_ADDR + TYPE)


#removes unnecessary offset
PAYLOAD.remove('')


#store frame in dictionary
EFrame= {'DST_MAC_ADDR' : DST_MAC_ADDR,
     'SRC_MAC_ADDR' : SRC_MAC_ADDR,
     'TYPE' : TYPE,
     'PAYLOAD' : PAYLOAD,
     }

#write to html file
f = open('EFrame.html','w')

message = ""

message += "<html>"
message  += "<body bgcolor=\"white\">"
message  += "<table border=\"3\" cellspacing=\"0\" cellpadding=\"20\">"



#show frame information in tabular format
for i in range(len(PAYLOAD)):

    message  += "<tr>"
    message += '<td>%s : %s</td>' % ('DST_MAC_ADDR', EFrame['DST_MAC_ADDR'])
    message += '<td>%s : %s</td>' % ('SRC_MAC_ADDR', EFrame['SRC_MAC_ADDR'])
    message += '<td>%s : %s</td>' % ('TYPE', EFrame['TYPE'])
    message += '<td>%s : %s</td>' % ('PAYLOAD', EFrame['PAYLOAD'][i])
    message += '<tr>'




message  += "</table>"
message  += "</body>"
message  += "</html>"

f.write(message)
f.close()




