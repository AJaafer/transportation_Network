from urllib.request import urlopen
import urllib.request
import os

def web_retrive():
    
    data = urlopen('http://engineering.usask.ca/ece/syllabi-CME.php')
    text = data.read().decode('utf-8').split("</a>")
    start_tag = '<a href="'
    end_tag = '"'
    count = 0
    links = []
    
    for item in text:
        
        if start_tag in item:
            index = item.index(start_tag)
            item = item[index+len(start_tag):]
            end = item.index(end_tag)
            links.append(item[:end])

    uni_list = []       
    for link in links:
        if link not in uni_list:
            uni_list.append(link)
            count+= 1

    print (count)


    #part B
    toSort = []
    for link in links:

        
        if ".pdf" in link:
            
           index = link.index('/') 
           toSort.append(link[index+1: ])

    sorted(toSort, reverse = False)
    
    for filename in toSort:
        
        print(filename)


    #part C
    #used to create the subdirectory
    #os.makedirs('H:/Year_3_2/CME451/Lab/lab02/PDF_files')
     
    for link in links:

        
        if ".pdf" in link:
            
            urllib.request.urlretrieve(link, "/file")
        
    sorted(toSort, reverse = False)
