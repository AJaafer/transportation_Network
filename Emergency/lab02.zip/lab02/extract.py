import os
import re
from urllib.request import urlopen


def extract():

    #used to create the subdirectory
    #makedirs('H:/Year_3_2/CME451/Lab/lab02')
    
    data = urlopen('http://engineering.usask.ca/ece/syllabi-CME.php')
    html_file = open ("ece.html", "w")
    text = data.read().decode('utf-8')
    html_file.write(text)
    
    
    #searching for '.png' string on webpage

    #print(text)
    #index = text.index('src="') +1
    #secondIndex = (text[index+1 : ].index('"')) + index + 1
    #print (text[index: secondIndex])
    
    matches = re.findall('<img [^>]*src="([^"]+)', text)
    for match in matches:
        print(match)
    html_file.close()
