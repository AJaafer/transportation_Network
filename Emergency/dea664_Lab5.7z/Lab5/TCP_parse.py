# This script exracts IP headers, parsers the header information into
# human readable format and saves them as pairs of <fields:value>

# It also generates an HTML file and displays the dictionary items
# in a tabular format

stream = ("f7500050ce0a0711208ae25c50181020da3f0000")

#parsing of the tcp packet.
SRC= stream[0:4]
DST = stream[4:8]
SEQ = stream[8:16]
ACK_NO = stream[16:24]
HLEN = stream[24]
SECTION = stream[25:28]
SECTION = (bin(int(SECTION, 16))[2:]).zfill(12)
RESERVED = (hex(int(SECTION[0:6], 2))[2:]).zfill(2)

#Parsing of CONTROL
URG = SECTION[6]
ACK = SECTION[7]
PSH = SECTION[8]
RST = SECTION[9]
SYN = SECTION[10]
FIN = SECTION[11]


WINDOW = stream[28:32]
CHECKSUM = stream[32:36]
UPOINTER = stream[36:40] 
OPTIONS = stream[40:50]
DATA = stream[50:]



#store packet in dictionary
IP= {'SRC' : SRC,
     'DST' : DST,
     'SEQ' : SEQ,
     'ACK_NO' : ACK_NO,
     'HLEN' : HLEN,
     'RESERVED' : RESERVED,
     'URG' : URG,
     'ACK' : ACK,
     'PSH' : PSH,
     'RST' : RST,
     'SYN' : SYN,
     'FIN' : FIN,
     'WINDOW' : WINDOW,
     'CHECKSUM' : CHECKSUM,
     'UPOINTER' : UPOINTER,
     'OPTIONS' : OPTIONS,
     'DATA' : DATA,
    
     }

print(IP)

#write to html file
f = open('tcp.html','w')

message = ""


message += "<html>"
message  += "<body bgcolor=\"white\">"



message  += "<table border= \"1\" >"
message  += "<tr>"
message += '<td width="890" align="center">%s: %s</td>' % ('SRC. PORT ADDR', IP['SRC'])
message += '<td width="890" align="center">%s : %s</td>' % ('DST. PORT ADDR', IP['DST'])
message += "</tr>"
message  += "</table>"

message  += "<table border= \"1\" >"
message  += "<tr>"
message += '<td  width="1785" align="center">%s : %s</td>' % ('SEQUENCE NO', IP['SEQ'])
message += '</tr>'
message  += "</table>"

message  += "<table border= \"1\" >"
message  += "<tr>"
message += '<td width="1785" align="center">%s : %s</td>' % ('ACKNOWLEDGMENT NO', IP['ACK_NO'])
message += '</tr>'
message  += "</table>"

message  += "<table border= \"1\" >"
message  += "<tr>"
message += '<td width="170" align="center">%s : %s</td>' % ('HLEN', IP['HLEN'])
message += '<td width="230" align="center">%s : %s</td>' % ('RESERVED', IP['RESERVED'])
message += '<td width="120" align="center">%s : %s</td>' % ('URG', IP['URG'])
message += '<td width="100" align="center">%s : %s</td>' % ('ACK', IP['ACK'])
message += '<td width="100" align="center">%s : %s</td>' % ('PSH', IP['PSH'])
message += '<td width="100" align="center">%s : %s</td>' % ('RST', IP['RST'])
message += '<td width="100" align="center">%s : %s</td>' % ('SYN', IP['SYN'])
message += '<td width="100" align="center">%s : %s</td>' % ('FIN', IP['FIN'])
message += '<td width="717" align="center">%s : %s</td>' % ('WINDOW', IP['WINDOW'])
message += '<tr>'
message  += "</table>"

message  += "<table border= \"1\" >"
message  += "<tr>"
message += '<td width="890" align="center" >%s : %s</td>' % ('CHECKSUM', IP['CHECKSUM'])
message += '<td width="890" align="center" >%s : %s</td>' % ('URGENT POINTER', IP['UPOINTER'])
message += '<tr>'
message  += "</table>"

message  += "<table border= \"1\" >"
message  += "<tr>"
message += '<td width="1785" align="center">%s : %s</td>' % ('OPTIONS AND PADDING ', IP['OPTIONS'])
message += '<tr>'
message  += "</table>"

message  += "<table border= \"1\" >"
message  += "<tr>"
message += '<td width="1785" align="center">%s : %s</td>' % ('DATA', IP['DATA'])
message += '<tr>'
message  += "</table>"

message  += "</body>"
message  += "</html>"

f.write(message)
f.close()
