import math
import re

#original fragment

TL = 5020
ID = 45678
DF= 0
MF= 0
FO = 000
START_DATA = 0000
END_DATA = 4999

IP= {'VERSION' : '',
        'HLEN' : '',
        'TYPE OF SERVICE' : '',
        'TOTAL_LENGTH' : TL,
        'IDENTIFICATION' : ID,
        'DF' : DF,
        'MF' : MF,
        'FRAGMENTATION OFFSET' : FO,
        'TIME TO LIVE' : '',
        'PROTOCOL' : '',
        'HEADER_CHECKSUM' : '',
         'DATA' : '%s - %s' %(START_DATA, END_DATA)
                     
                     
                     }


def html(message):

    message += "<table border=\"1\" width=\"100%\">"
    message += "<tr>"
    message += '<td colspan="1">%s  %s</td>' % ('', IP['VERSION'])
    message += '<td colspan="10">%s  %s</td>' % ('', IP['HLEN'])
    message += '<td colspan="10">%s  %s</td>' % ('', IP['TYPE OF SERVICE'])
    message += '<td colspan="20">%s  %s</td>' % ('TOTAL LENGTH: ', IP['TOTAL_LENGTH'])
    message += '</tr>'

    message  += "<tr>"
    message += '<td>%s  %s</td>' % ('IDENTIFICATION:', IP['IDENTIFICATION'])
    message += '<td>%s  %s</td>' % ('', IP['DF'])
    message += '<td>%s  %s</td>' % ('', IP['MF'])
    message += '<td>%s  %s</td>' % ('FRAGMENTATION OFFSET: ', IP['FRAGMENTATION OFFSET'])
    message += '</tr>'

    message  += '<tr> <td colspan="5"></td> </tr>'
    message  += '<tr> <td colspan="5"></td> </tr>'

    message  += "<tr >"
    message += '<td>%s : %s</td>' % ('DATA: Bytes', IP['DATA'])
    message += '</tr>'

    message  += "</table>"

    return message    

    


def fragment(MTU):
    #write to html file
    f = open('fragmentation.html','w')

    message = ""
    
    global TL, ID, DF, MF
    global FO, START_DATA, END_DATA
    
    if((IP['FRAGMENTATION OFFSET'] == 0) or (IP['MF'] == 1)):
        
        message += "<!DOCTYPE html>"
        message += "<html>"
        message  += "<body bgcolor=\"white\">"
        
        message  += "<p> Original Packet</p>"
        message = html(message)
        
    #####################fragmentation occurs here

    #using an MTU of 1400
    

    #need to get the number of fragments needed

    frags = math.ceil(END_DATA/float(MTU)) 


    print (frags)

    count = 0 
    while  ((count < frags)):

        
        # need to recalculate offset, MF and total length

        if ((count+1) == frags):
            IP['MF'] = 0

        else:
            IP['MF'] = 1


        
        print ("MTU :" + str(MTU))
        print ("count :" + str (count))

        print (TL)
        
        if(((TL-20) - (MTU * count)) > MTU):
            IP['TOTAL_LENGTH'] = MTU + 20

        else:
            IP['TOTAL_LENGTH'] = TL - (MTU * count)

        print (IP['FRAGMENTATION OFFSET'])
        print (IP['MF'])
        
        #beginning of the fragment
        if(count == 0):
            START_DATA = 0000

        else:
            START_DATA = END_DATA + 1

        END_DATA = START_DATA + IP['TOTAL_LENGTH'] - 21
        
        IP['DATA'] = '%s - %s' %(START_DATA, END_DATA)                          


        IP['FRAGMENTATION OFFSET'] = START_DATA/ 8
        
        message +=  "<p> packet: %i </p>" %(count+1)
        message = html(message)

        

        #reduce count
        count += 1
        


        ##############part2
        if (count+1 == 2):

            # need to send second fragmented datagram through X25 network
            numfrag = math.ceil(float(MTU) / 556)
            count2 = 0;

            MTU = 576

            
            LENGTH2 = IP['TOTAL_LENGTH'] + int((numfrag *20)) - 20


            #need to change the total length, fragmentation offset
            #and number of bytes
            
            while (count2 < numfrag):

                
                if(((LENGTH2) - (MTU * count2)) > MTU):
                    IP['TOTAL_LENGTH'] = MTU

                else:
                    IP['TOTAL_LENGTH'] = LENGTH2 - (MTU * count2)
                    

                START_DATA = END_DATA + 1
                IP['FRAGMENTATION OFFSET'] = START_DATA/ 8

                END_DATA = START_DATA + IP['TOTAL_LENGTH'] - 21
                IP['DATA'] = '%s - %s' %(START_DATA, END_DATA) 
                message +=  "<p> packet: 2%s </p>" %(chr(ord('a')+ int(count2)))
                message = html(message)

                
                
                count2 += 1


            MTU = 1400
            count +=1
       

    message  += "</body>"
    message  += "</html>"




    f.write(message)
    f.close()



def recombine(number):


    #first split according to tables
    #neglect 0 ofset as it is the orignal datagram
    #check if the identification as one provided and if so add to datagram

    f = open('fragmentation.html')
    html = f.read().decode('utf-8')
    f.close()

    number = str(number)
    combine = open('combined.html', 'w')
    tables = html.split('</table>')

    message = ""
    message += "<!DOCTYPE html>"
    message += "<html>"
    message  += "<body bgcolor=\"white\">"
    for each in tables[1:]:

        #check if the idenfication number is correct
        if(re.search(number, each)):
            print(each)
            combine.write(each)    
            combine.write("</table>")

    message  += "</body>"
    message  += "</html>"
    combine.write(message)   
    combine.close()

    
   

    
