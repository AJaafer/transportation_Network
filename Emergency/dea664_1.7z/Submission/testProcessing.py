import operator

def testProcessing():
    
    #A file object is created
    txtFile = open("record.txt", "r")

    # Create an empty list to store the student records
    myList = []
    

    
    for line in txtFile:

        
        fields = line.split(",")
        #recod must have no less than 3 fields
        if(len(fields) >= 3):

            
            myList.append(line)
  
                
    #sorts the list according to marks or if there is a tie, NSID                
    list1 = sorted(myList, key = operator.itemgetter(2, 0), reverse = True)
    
    #prints out the record
    for line in list1:

        print(line)

    #closes the file stream
    txtFile.close()


